package hostelManagementSystem;


import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/hostel_management?useSSL=false&characterEncoding=UTF-8",
            "root",
            "saurav167281"
        );
    }
}

