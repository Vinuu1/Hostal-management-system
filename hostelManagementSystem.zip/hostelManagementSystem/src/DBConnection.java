

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");  // MySQL 5.x driver
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/hostel_management?useUnicode=true&characterEncoding=UTF-8",
            "root",
            "saurav167281"
        );
    }
}
