import java.io.IOException;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String action = request.getParameter("action");

        // ✅ ADD STUDENT
        if ("add".equals(action)) {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            int courseId = Integer.parseInt(request.getParameter("course_id"));
            String roomIdParam = request.getParameter("room_id");
            Integer roomId = (roomIdParam != null && !roomIdParam.isEmpty()) ? Integer.parseInt(roomIdParam) : null;

            try (Connection con = DBConnection.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO students (name, email, password, course_id, room_id) VALUES (?, ?, ?, ?, ?)");
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, password);
                ps.setInt(4, courseId);
                if (roomId != null) ps.setInt(5, roomId);
                else ps.setNull(5, java.sql.Types.INTEGER);

                ps.executeUpdate();
                response.sendRedirect("manageStudents.jsp?msg=Student added successfully!");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("manageStudents.jsp?error=Error adding student!");
            }
        }

        // ✅ UPDATE STUDENT
        else if ("update".equals(action)) {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String roomIdParam = request.getParameter("room_id");
            Integer roomId = (roomIdParam != null && !roomIdParam.isEmpty()) ? Integer.parseInt(roomIdParam) : null;

            try (Connection con = DBConnection.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE students SET name=?, email=?, password=?, room_id=? WHERE id=?");
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, password);
                if (roomId != null) ps.setInt(4, roomId);
                else ps.setNull(4, java.sql.Types.INTEGER);
                ps.setInt(5, Integer.parseInt(id));

                ps.executeUpdate();
                response.sendRedirect("manageStudents.jsp?msg=Student updated successfully!");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("manageStudents.jsp?error=Error updating student!");
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String action = request.getParameter("action");
        String id = request.getParameter("id");

        try (Connection con = DBConnection.getConnection()) {
            if ("delete".equals(action)) {
                PreparedStatement ps = con.prepareStatement("DELETE FROM students WHERE id=?");
                ps.setInt(1, Integer.parseInt(id));
                ps.executeUpdate();
                response.sendRedirect("manageStudents.jsp?msg=Student deleted successfully!");
            } else if ("edit".equals(action)) {
                response.sendRedirect("editStudent.jsp?id=" + id);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("manageStudents.jsp?error=Database error!");
        }
    }
}
