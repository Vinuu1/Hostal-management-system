import java.io.IOException;
import java.sql.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws  IOException {
        String action = request.getParameter("action");

        if("register".equals(action)) {
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String course = request.getParameter("course");

            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users (fullname,email,password,course) VALUES (?,?,?,?)"
                );
                ps.setString(1, fullname);
                ps.setString(2, email);
                ps.setString(3, password);
                ps.setString(4, course);
                ps.executeUpdate();
                con.close();

                response.sendRedirect("userLogin.jsp?msg=Registered successfully! Login now.");
            } catch(Exception e) {
                e.printStackTrace();
                response.sendRedirect("userRegister.jsp?error=Error registering user!");
            }
        }

        else if("login".equals(action)) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM users WHERE email=? AND password=?"
                );
                ps.setString(1, email);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();

                if(rs.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("userId", rs.getInt("id"));
                    session.setAttribute("userName", rs.getString("fullname"));
                    response.sendRedirect("userDashboard.jsp");
                } else {
                    response.sendRedirect("userLogin.jsp?error=Invalid credentials!");
                }
                con.close();
            } catch(Exception e) {
                e.printStackTrace();
                response.sendRedirect("userLogin.jsp?error=Database error!");
            }
        }
    }
}
