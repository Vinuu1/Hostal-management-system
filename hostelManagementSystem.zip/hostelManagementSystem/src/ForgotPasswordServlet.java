import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ForgotPasswordServlet")
public class ForgotPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handle GET requests: redirect to the forgotPassword.jsp form
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("forgotPassword.jsp");
    }

    // Handle POST requests: process form submission
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        if(email == null || email.trim().isEmpty()) {
            response.sendRedirect("forgotPassword.jsp?error=Please enter your email!");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT password FROM students WHERE email = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                String password = rs.getString("password");
                // In real apps, you would send this via email instead of displaying it!
                response.sendRedirect("forgotPassword.jsp?msg=Your password is: " + password);
            } else {
                response.sendRedirect("forgotPassword.jsp?error=Email not found!");
            }

        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect("forgotPassword.jsp?error=Database error!");
        }
    }
}
