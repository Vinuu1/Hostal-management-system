import java.io.IOException;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ComplaintServlet")
public class ComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handle GET requests safely
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirect to the complaint registration page
        response.sendRedirect("registerComplaint.jsp");
    }

    // Handle POST requests (submit complaint)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentIdParam = request.getParameter("student_id");
        String complaintText = request.getParameter("complaint_text");

        if (studentIdParam == null || complaintText == null || complaintText.trim().isEmpty()) {
            response.sendRedirect("registerComplaint.jsp?error=Please enter your complaint!");
            return;
        }

        int studentId;
        try {
            studentId = Integer.parseInt(studentIdParam);
        } catch (NumberFormatException e) {
            response.sendRedirect("registerComplaint.jsp?error=Invalid student ID!");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;

        try {
        	Class.forName("com.mysql.jdbc.Driver"); // load driver if needed
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hostel_management", "root", "password");

            String sql = "INSERT INTO complaints (student_id, complaint_text, status) VALUES (?, ?, ?)";
            ps = con.prepareStatement(sql);
            ps.setInt(1, studentId);
            ps.setString(2, complaintText);
            ps.setString(3, "Pending");
            ps.executeUpdate();

            response.sendRedirect("registerComplaint.jsp?msg=Complaint submitted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("registerComplaint.jsp?error=Database error while submitting complaint!");
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            try { if (ps != null) ps.close(); } catch (Exception ex) {}
            try { if (con != null) con.close(); } catch (Exception ex) {}
        }
    }
}
