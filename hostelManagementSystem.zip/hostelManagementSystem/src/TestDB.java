import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestDB {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/hostel_management?useSSL=false"; // your DB URL
        String username = "root";     // your MySQL username
        String password = "saurav167281"; // your MySQL password

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish connection
            Connection con = DriverManager.getConnection(url, username, password);

            if (con != null) {
                System.out.println("Database connected successfully!");
                con.close();
            }
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Failed to connect to database!");
            e.printStackTrace();
        }
    }
}
