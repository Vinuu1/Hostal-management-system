import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RoomServlet")
public class RoomServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBConnection.getConnection();

            // ------------------- ADMIN: ADD ROOM -------------------
            if ("add".equals(action)) {
                String roomNo = request.getParameter("room_no");
                String fees = request.getParameter("fees");

                ps = con.prepareStatement("INSERT INTO rooms (room_no, fees) VALUES (?, ?)");
                ps.setString(1, roomNo);
                ps.setDouble(2, Double.parseDouble(fees));
                ps.executeUpdate();
                response.sendRedirect("manageRooms.jsp?msg=Room added successfully!");
                return;
            }

            // ------------------- STUDENT: BOOK ROOM -------------------
            String studentIdParam = request.getParameter("studentId");
            String roomIdParam = request.getParameter("room_id");

            if(studentIdParam != null && roomIdParam != null && !roomIdParam.isEmpty()) {
                int studentId = Integer.parseInt(studentIdParam);
                int roomId = Integer.parseInt(roomIdParam);

                ps = con.prepareStatement("SELECT id FROM students WHERE room_id=?");
                ps.setInt(1, roomId);
                rs = ps.executeQuery();
                if(rs.next()) {
                    response.sendRedirect("bookHostel.jsp?error=This room is already booked!");
                    return;
                }
                if(rs != null) { rs.close(); }

                ps = con.prepareStatement("UPDATE students SET room_id=? WHERE id=?");
                ps.setInt(1, roomId);
                ps.setInt(2, studentId);
                ps.executeUpdate();
                response.sendRedirect("bookHostel.jsp?msg=Room booked successfully!");
                return;
            }

            // ------------------- ADMIN: UPDATE ROOM -------------------
            if ("update".equals(action)) {
                String id = request.getParameter("id");
                String roomNo = request.getParameter("room_no");
                String fees = request.getParameter("fees");

                ps = con.prepareStatement("UPDATE rooms SET room_no=?, fees=? WHERE id=?");
                ps.setString(1, roomNo);
                ps.setDouble(2, Double.parseDouble(fees));
                ps.setInt(3, Integer.parseInt(id));
                ps.executeUpdate();
                response.sendRedirect("manageRooms.jsp?msg=Room updated successfully!");
                return;
            }

        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect("manageRooms.jsp?error=Database error!");
        } finally {
            try { if(rs != null) rs.close(); } catch(Exception ex) {}
            try { if(ps != null) ps.close(); } catch(Exception ex) {}
            try { if(con != null) con.close(); } catch(Exception ex) {}
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        String id = request.getParameter("id");

        Connection con = null;
        PreparedStatement ps = null;

        try {
            con = DBConnection.getConnection();

            // ------------------- ADMIN: DELETE ROOM -------------------
            if ("delete".equals(action) && id != null) {
                ps = con.prepareStatement("DELETE FROM rooms WHERE id=?");
                ps.setInt(1, Integer.parseInt(id));
                ps.executeUpdate();
                response.sendRedirect("manageRooms.jsp?msg=Room deleted successfully!");
                return;
            }

            // ------------------- ADMIN: EDIT ROOM -------------------
            if ("edit".equals(action) && id != null) {
                response.sendRedirect("updateRoom.jsp?id=" + id);
                return;
            }

            response.sendRedirect("manageRooms.jsp?error=Invalid action!");

        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect("manageRooms.jsp?error=Database error!");
        } finally {
            try { if(ps != null) ps.close(); } catch(Exception ex) {}
            try { if(con != null) con.close(); } catch(Exception ex) {}
        }
    }
}
