import java.io.IOException;
import java.sql.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CourseServlet")
public class CourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws  IOException {
        String action = request.getParameter("action");
        if(action != null && action.equals("add")) {
            String courseName = request.getParameter("course_name");
            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement("INSERT INTO courses (course_name) VALUES (?)");
                ps.setString(1, courseName);
                ps.executeUpdate();
                con.close();
                response.sendRedirect("manageCourses.jsp?msg=Course added successfully!");
            } catch(Exception e) {
                e.printStackTrace();
                response.sendRedirect("manageCourses.jsp?error=Error adding course!");
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws  IOException {
        String action = request.getParameter("action");
        String id = request.getParameter("id");

        try {
            Connection con = DBConnection.getConnection();
            if(action != null && action.equals("delete")) {
                PreparedStatement ps = con.prepareStatement("DELETE FROM courses WHERE id = ?");
                ps.setInt(1, Integer.parseInt(id));
                ps.executeUpdate();
                response.sendRedirect("manageCourses.jsp?msg=Course deleted successfully!");
            } else if(action != null && action.equals("edit")) {
                // Redirect to edit page or use a prompt for simplicity
                response.sendRedirect("editCourse.jsp?id=" + id);
            }
            con.close();
        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect("manageCourses.jsp?error=Database error!");
        }
    }
}
