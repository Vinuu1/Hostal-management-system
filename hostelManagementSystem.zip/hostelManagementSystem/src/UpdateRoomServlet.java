import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/UpdateRoomServlet")
public class UpdateRoomServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String id = request.getParameter("id");
        String roomNo = request.getParameter("room_no");
        String fees = request.getParameter("fees");

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("UPDATE rooms SET room_no = ?, fees = ? WHERE id = ?");
            ps.setString(1, roomNo);
            ps.setDouble(2, Double.parseDouble(fees));
            ps.setInt(3, Integer.parseInt(id));
            ps.executeUpdate();
            con.close();

            response.sendRedirect("manageRooms.jsp?msg=Room updated successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("manageRooms.jsp?error=Error updating room!");
        }
    }
}
