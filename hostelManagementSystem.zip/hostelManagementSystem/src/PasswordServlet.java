import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/PasswordServlet")
public class PasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws  IOException {

        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("userLogin.jsp");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        String currentPassword = request.getParameter("current_password");
        String newPassword = request.getParameter("new_password");
        String confirmPassword = request.getParameter("confirm_password");

        if(!newPassword.equals(confirmPassword)) {
            response.sendRedirect("changePassword.jsp?error=New passwords do not match.");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();

            // Verify current password
            String sqlCheck = "SELECT password FROM users WHERE id = ?";
            PreparedStatement psCheck = con.prepareStatement(sqlCheck);
            psCheck.setInt(1, userId);
            ResultSet rs = psCheck.executeQuery();

            if(rs.next()) {
                String dbPassword = rs.getString("password");
                if(!dbPassword.equals(currentPassword)) {
                    response.sendRedirect("changePassword.jsp?error=Current password is incorrect.");
                    con.close();
                    return;
                }
            }

            // Update password
            String sqlUpdate = "UPDATE users SET password = ? WHERE id = ?";
            PreparedStatement psUpdate = con.prepareStatement(sqlUpdate);
            psUpdate.setString(1, newPassword);
            psUpdate.setInt(2, userId);

            int i = psUpdate.executeUpdate();
            if(i > 0) {
                response.sendRedirect("changePassword.jsp?msg=Password changed successfully!");
            } else {
                response.sendRedirect("changePassword.jsp?error=Failed to change password.");
            }

            con.close();
        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect("changePassword.jsp?error=Database error occurred!");
        }
    }
}
