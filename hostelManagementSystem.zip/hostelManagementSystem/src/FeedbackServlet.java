import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/FeedbackServlet")
public class FeedbackServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws  IOException {

        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("userLogin.jsp");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        String feedbackText = request.getParameter("feedback_text");

        try {
            Connection con = DBConnection.getConnection();
            String sql = "INSERT INTO feedback (user_id, feedback_text) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setString(2, feedbackText);

            int i = ps.executeUpdate();
            if(i > 0) {
                response.sendRedirect("feedback.jsp?msg=Feedback submitted successfully!");
            } else {
                response.sendRedirect("feedback.jsp?error=Failed to submit feedback.");
            }

            con.close();
        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect("feedback.jsp?error=Database error occurred!");
        }
    }
}
